﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack<int> m = new Stack<int>();
            Console.Write("Введите название файла: ");
            string name = Console.ReadLine();
            int k = 0;
            if (File.Exists(name + ".txt"))
            {
                if (new FileInfo(name + ".txt").Length == 0)
                {
                    Console.WriteLine("Файл пустой");
                }
                else
                {
                    string[] m2 = File.ReadAllLines(name + ".txt");
                    for (int j = 0; j < m2.Length; j++)
                    {
                        Console.WriteLine(m2[j]);
                        for (int i = 0; i < m2[j].Length; i++)
                        {
                            Random r = new Random();
                            char c = m2[j][i];
                            int number = Convert.ToInt32(m2[j][0].ToString());
                            if (char.IsDigit(c))
                            {
                                m.Push(Convert.ToInt32(c.ToString()));
                            }
                            else if (c == 'm')
                            {
                                int a = r.Next(0, number);
                                int b = r.Next(0, number);
                                int ot = (a - b) % 10;
                             m.Push(ot);
                            }
                            else if (c == 'p')
                            {
                                int a = r.Next(0, number);
                                int b = r.Next(0, number);
                                int ot = (a + b) % 10;
                              m.Push(ot);
                            }
                        }
                        Console.WriteLine(m.Pop());
                    }
                }
            }
            else
            {
                Console.WriteLine("Файл не найден");
            }
        Console.ReadKey();
            }
        }
    }    
